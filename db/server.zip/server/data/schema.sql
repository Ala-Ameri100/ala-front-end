Create table questions (
 	id SERIAL,
	"Topic" varchar(50),
	"Difficulty Level" varchar(10),
	"Question Full" varchar(1000),
	"Answer" varchar(1000),
	"Question Text" varchar(1000),
	"Choices" varchar(1000),
	"Genere" varchar(20),
	"Question Tags" varchar(1000)
)